package com.example.semaforoapp

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var luzRoja: ImageView
    private lateinit var luzAmarilla: ImageView
    private lateinit var luzVerde: ImageView
    private lateinit var horaTextView: TextView
    private lateinit var btnRecargar: Button

    private val API_URL = "http://192.168.1.136:8000/api/color-alerta/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        luzRoja = findViewById(R.id.luzRoja)
        luzAmarilla = findViewById(R.id.luzAmarilla)
        luzVerde = findViewById(R.id.luzVerde)
        horaTextView = findViewById(R.id.horaTextView)
        btnRecargar = findViewById(R.id.btnRecargar)

        apagarLuces()
        obtenerColorDesdeServidor()

        btnRecargar.setOnClickListener {
            obtenerColorDesdeServidor()
        }
    }

    private fun apagarLuces() {
        luzRoja.alpha = 0.3f
        luzAmarilla.alpha = 0.3f
        luzVerde.alpha = 0.3f
    }

    private fun obtenerColorDesdeServidor() {
        thread {
            try {
                val url = URL(API_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val color = json.getString("color")
                val hora = json.optString("hora", "--:--:--")

                runOnUiThread {
                    apagarLuces()
                    horaTextView.text = "Hora: $hora"
                    when (color.lowercase()) {
                        "rojo" -> luzRoja.alpha = 1f
                        "amarillo" -> luzAmarilla.alpha = 1f
                        "verde" -> luzVerde.alpha = 1f
                        else -> apagarLuces()
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    apagarLuces()
                    horaTextView.text = "Error al conectar"
                }
            }
        }
    }
}
