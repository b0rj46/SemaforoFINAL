from django.apps import AppConfig

class ProyectoConfig(AppConfig):
    name = 'Proyecto'  # Asegúrate que coincide con el nombre del proyecto

    def ready(self):
        # Solo activa el scheduler si no estamos en modo de migración
        import sys
        if 'runserver' in sys.argv or 'uwsgi' in sys.argv:
            from scheduler.scheduler import iniciar_scheduler
            iniciar_scheduler()
