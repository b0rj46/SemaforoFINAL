from rest_framework import serializers
from .models import ConsumoDiario

class ConsumoDiarioSerializer(serializers.ModelSerializer):
    total = serializers.SerializerMethodField()

    class Meta:
        model = ConsumoDiario
        fields = ['id', 'fecha_exacta', 'precio', 'peaje', 'cargo', 'total']

    def get_total(self, obj):
        return obj.precio + obj.peaje + obj.cargo 