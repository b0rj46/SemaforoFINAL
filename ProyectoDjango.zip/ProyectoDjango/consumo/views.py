from rest_framework.decorators import api_view
from rest_framework.response import Response
from consumo.models import ConsumoDiario
from django.utils.timezone import localtime

@api_view(['GET'])
def color_alerta(request):
    try:
        consumo = ConsumoDiario.objects.order_by('-id').first()
        if consumo is None:
            raise ValueError("No hay datos en la base de datos.")
        
        return Response({"color": consumo.color_alerta,
                        "hora": localtime(consumo.fecha_exacta).strftime("%H:%M:%S")
                         })

    except Exception as e:
        return Response({"error": str(e)}, status=500)