from django.apps import AppConfig


class ConsumoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consumo'
