from django.urls import path
from .views import color_alerta

urlpatterns = [
    path('api/color-alerta/', color_alerta, name='color_alerta'),
]
