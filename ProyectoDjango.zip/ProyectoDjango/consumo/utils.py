from django.utils import timezone
from consumo.models import ConsumoDiario

def obtener_datos_desde_bd(fecha=None):
    if not fecha:
        fecha = timezone.now()

    # Redondea al inicio de la hora (ignora minutos y segundos)
    fecha = fecha.replace(minute=0, second=0, microsecond=0)

    try:
        datos = ConsumoDiario.objects.get(fecha_exacta=fecha)
        return {
            "fecha": datos.fecha_exacta,
            "precio": datos.precio,
            "peaje": datos.peaje,
            "cargo": datos.cargo,
            "total": datos.precio + datos.peaje + datos.cargo
        }
    except ConsumoDiario.DoesNotExist:
        raise ValueError(f"No se encontraron datos para la fecha {fecha}")
