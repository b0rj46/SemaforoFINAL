import os
from django.apps import AppConfig

class SchedulerConfig(AppConfig):
    name = 'scheduler'

    def ready(self):
        # Solo iniciar una vez (evitar doble ejecución del scheduler con autoreloader)
        if os.environ.get('RUN_MAIN', None) != 'true':
            return
        from .scheduler import start
        start()
