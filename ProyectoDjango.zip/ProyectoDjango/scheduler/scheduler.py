from apscheduler.schedulers.background import BackgroundScheduler
from scraper.core import guardar_consumo

scheduler = None  # 👈 protección global

def start():
    global scheduler
    if scheduler is None:
        scheduler = BackgroundScheduler()
        scheduler.add_job(
            guardar_consumo,
            'interval',
            minutes=2,
            id='guardar_consumo_job',
            max_instances=1,
            replace_existing=True
        )
        scheduler.start()
        print("✅ Scheduler iniciado")
    else:
        print("⚠️ Scheduler ya estaba iniciado, no se repite")
