from django.urls import path, include

urlpatterns = [
    path('consumo/', include('consumo.urls')),
    path('', include('consumo.urls')),
]
